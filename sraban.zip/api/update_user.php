<?php
require('db.php');
// storing  request (ie, get/post) global array to a variable  
if(!empty($_REQUEST) ) {
	
	extract($_REQUEST);
	if($id ){
		
		if( strlen($password) < 9 ) {
			echo exit(json_encode(['error' => 'Password should be minimum 10 character' ]));
		}
		
		$sql = "update users set fname = '$fname', lname = '$lname', password = '$password' where id = '$id'";
		$query=mysqli_query($conn, $sql);
		echo json_encode(['status' => 'Success'] );
		
	} else {
		echo json_encode(['error' => 'Please input all the fields...' ]);
	}

}


?>
