<?php
require('db.php');
// storing  request (ie, get/post) global array to a variable  

$id = @$_REQUEST['id'];
if($id){
$sql = "SELECT `id`, `fname`, `lname`, `email`, `password` ";
$sql.=" FROM users WHERE `id` = '".$id."'";

$query=mysqli_query($conn, $sql) or die("get ");
$row=mysqli_fetch_assoc($query);
	echo json_encode($row);  // send data as json format
} else {
	echo json_encode([ 'error' => 'Not a Valid User' ]);
}
?>
