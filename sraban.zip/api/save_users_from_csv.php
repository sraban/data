<?php
if(!empty($_FILES)) {
	require('db.php');
	require('JWT.php');
	
	$temporary = explode(".", $_FILES["upload_csv"]["name"]);
	$file_extension = end($temporary);
	
	if(strtolower($file_extension) == "csv" ) {
		
			//open uploaded csv file with read only mode
			$csvFile = fopen($_FILES['upload_csv']['tmp_name'], 'r');
			
			//skip first line //fgetcsv($csvFile); //parse data from csv file line by line
			
			while(($line = fgetcsv($csvFile)) !== FALSE){
				$prevQuery = "SELECT id FROM users WHERE email = '".$line[3]."'";
				$query=mysqli_query($conn, $prevQuery);
				if( !mysqli_num_rows($query) ) {
					$sql = "insert into users set fname = '$line[1]', lname = '$line[2]', email = '$line[3]', password = '$line[4]'";
					$query=mysqli_query($conn, $sql);
				}
			}
			//close opened csv file
			fclose($csvFile);
			
			echo json_encode(['status'=>'Success']);
	} else {
		echo json_encode(['status' => 'not a csv file'] );
	}

}
?>