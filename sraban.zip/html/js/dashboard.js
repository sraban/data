            
    function getCookie(name)
    {
      var re = new RegExp(name + "=([^;]+)");
      var value = re.exec(document.cookie);
      return (value != null) ? unescape(value[1]) : null;
    }
    
    if(!getCookie("tokenVal")) window.location = "index.html";

	
	$('#saved_users').on("click",".pop_up",function() {
		
			var id = $(this).attr('src');
			$.ajax({
					url:"../api/view_users.php?id="+id,
					type:"get",
					dataType : "json",
					success:function(data) {
						
						$("#id").val(data.id); 
						$("#fname").val(data.fname);
						$("#lname").val(data.lname);
						$("#email").html(data.email);
						$("#password").val(data.password);
					
						$("#pop_me").trigger("click");                              
					}
			});
	});
	
	

    $.ajax({
        type:'post',
        data:{'token': getCookie("tokenVal") } ,
        url:"../api/retoken.php",
        dataType : 'json',
        success:function(data) {

		if(data && data.token) {
		
				$('body').attr('token', data.token );
			
                document.cookie="tokenVal="+ data.token;
                $("#username").html("Hi "+ data.info.name );
                //############
                var dataTable = $('#saved_users').DataTable( {
                                    "processing": true,
                                    "serverSide": true,
                                    "ajax":{
                                        url :"../api/users_ajax.php", // json datasource
                                        type: "post",  // method  , by default get
                                        error: function(){  // error handling
                                            $("#saved_users").append('<tbody class="error"><tr><th colspan="3">No data found in the server</th></tr></tbody>');
                                        }
                                    }
                                });
								
					$("#user_update").submit(function(e) {
						e.preventDefault();
						var token = $('body').attr('token');
						$('<input />').attr('type', 'hidden').attr('name', "token").attr('value', token ).appendTo('#user_update');
						
						$.ajax({
								url:"../api/update_user.php",
								type:"post",
								data : $("#user_update").serialize(),
								dataType: "Json" ,
								success:function(data) {
									
									 if(data.status == "Success" ) {
										 dataTable.ajax.reload();
										 $(".close").trigger("click");
										 alert("updated Successfully!!!!");
										 if(data.token) $('body').attr('token', data.token );
									 } else {
										alert(data.error);
									 }
									 
								}
						});
					});

				
				  $("#upload_csv_form").submit( function(e) {
							e.preventDefault();
							
                            if( $('#upload_csv').val().length > 0 ) {

								var form = $(this);
								var formdata = false;
								if (window.FormData){
									formdata = new FormData(form[0]);
								}							
                                $.ajax({
                                        url:"../api/save_users_from_csv.php",
                                        type:"post",
                                        data: formdata ,
                                        success:function(data) {
                                            dataTable.ajax.reload();
                                            alert("Successfully Imported to Record!!!!");                                
                                        },
										cache       : false,
										contentType : false,
										processData : false
                                });
                            } else {
                                alert("please Select the CSV File ???");
                            }
                    });

                //#############
            } else {
                window.location = "index.html";
            }
        }
    });
	

	

    $("#logout").click(function(e){
        e.preventDefault();
        document.cookie="tokenVal=";
        window.location = "index.html";
    });